#include "Network.h"


// the following DFS is designed to find the largest connected component in a directed or undirected graph
// for directed graph, the DFS is performed by searching the A_list, rather than Aout_list, of each node.
// So it cannot give the topological order of nodes.
void Network::DFS()
{
  vector<bool> visited(N, false);
  //vector<Nbl>  AllComponents; // all the connected components
  AllComponents.clear();
  
  int maxsize  = 0; // size of the largest connected component
  int lccindex = 0; // index of the largest connected component
  int ncc  = -1;    // count the number of connected component
  for(int i=0; i<N; i++) {
    if(!visited[i]) {
      ncc++; // find another connected component
      Nbl Component;
      DFS(i, visited, Component);
      AllComponents.push_back(Component);

      int size = Component.size();
      if(size>maxsize) {
	maxsize = size;
	lccindex = ncc;
      }

      //cout << "\n Component with size ("<< size  << "): "; //test
      //for(Nbl_itr p = Component.begin(); p!= Component.end(); p++) 
      //cout << (*p) << ' ';
    }
  }
  //cout << "\nThe largest connected component (label " << lccindex << ") has size = " << maxsize; //test
  lcc_index = lccindex; // 09/21/2015 

  Nlc = maxsize; // return the size of the largest connected component
  LC.clear();
  LC.resize(N);           // this vector labeling the node whether it belongs to the largest connected component


  Ncc = AllComponents.size();
  //cout << "There are total " << Ncc << " connected components.\n";
  cout << "# of connected components = " << Ncc << endl;


  ccindex.clear();
  ccindex.resize(N);
  int cc = 0;	
  Nac = 0;
  for(vector<Nbl>::iterator CC = AllComponents.begin(); CC!=AllComponents.end(); CC++) {
    for(Nbl_itr p = (*CC).begin(); p!= (*CC).end(); p++) {
      ccindex[*p]= cc;
    }
    int size = (*CC).size();
    Nac += size;
    cc++;
  }
  Nac = (Nac-Nlc)/(Ncc-1);

  cc = 0;	
  int sumKlc = 0;    // sum of k for the largest connected component
  int Kofleader = 0; // degree of the leader (the node with the highest degree in LCC)
  for(vector<Nbl>::iterator CC = AllComponents.begin(); CC!=AllComponents.end(); CC++) {
    if(cc==lccindex) { // if this is the largest component
	
      int count=0;
      for(Nbl_itr p = (*CC).begin(); p!= (*CC).end(); p++, count++) {
	//cout << (*p) << ' ' << K[(*p)] << endl; //debug
	//cout << (*p) << ' '; //debug

	LClist.push_back(*p);    // push it into the LClist
	LC[(*p)] = 1;            // label it 

	if(K[(*p)] > Kofleader) {
	  leader = (*p);
	  Kofleader = K[leader];
	}
	  
	sumKlc += K[(*p)];
      }
      break;
    }
    else
      cc++;
  }
  Kmaxlc = Kofleader;
    
  // calculate the number of edges in the largest connected component
  Elc = sumKlc/2;
  mlc = Elc/(double)Nlc;
  //cout << "\n Nlc = " << Nlc << " sumKlc= " << sumKlc << "  Elc=sumKlc/2= " << Elc << " mlc = Elc/Nlc= " << mlc << endl;
  cout << "Size of largest connected component = " << Nlc << endl; 

  //cout << "\nLC[] = ";
  //for(int i=0; i<N; i++) 
  //cout << LC[i] << ' '; //test
  //cout << " with leader node " << leader << ".\n";   //test


    
    
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////
  // In many calculations, we need to respect the mapping between the two sets of indices.
  // Here I, J are the indices in the original network
  //      i, j are the indices in the largest component
  // We consider only the largest connected component of the original network.
  // The nodes in this LC components are labeled with vector LC[i]=1.
  // We should delete those columns (and rows) with LC[i]=0 in the original adjacency matrix Ad. 
  // However, we must respect those nodes' original order in the original network. 
  // Therefore, we need a mapping between the two sets of indices.
  // This mapping is done by using two vertors: LCCIndexofOriginalnode and OriginalIndexofLCCnode

  LCCIndexofOriginalnode.clear();
  LCCIndexofOriginalnode.resize(N,-1);    // -1 means that this node does NOT belong to the LCC
  // LCCIndexof[i] give the in-largest-component index of the original network's i-th node
  OriginalIndexofLCCnode.clear();
  OriginalIndexofLCCnode.resize(Nlc); 
  // OriginalIndexof[i] give the original index of the largest component's i-th node 

  // also calculate the Kmin and Kmax of the LCC
  Kmax = 0;
  Kmin = N;
  int i=0;
  for(int I=0;I<N;I++) {
    if(LC[I]==1) {
      LCCIndexofOriginalnode[I] = i;
      OriginalIndexofLCCnode[i] = I;
      i++;
      
      if(K[I]>Kmax) Kmax = K[I];
      if(K[I]<Kmin) Kmin = K[I];
    }
  }
  //cout << "Kmax = " << Kmax << endl;
  //cout << "Kmin = " << Kmin << endl;
  ////////////////////////////////////////////////////////////////////////////////////////////////////////////



}
//////////////////////////////////////////////////////////////////////////////////////////////////////////// 





//////////////////////////////////////////////////////////////////////////////////////////////////////////// 
void Network::DFS(int u, vector<bool>& visited, Nbl&  Component)
{
  visited[u] = true;
  Component.push_back(u);
    
  //cout << "u = " << u ; //test
  // loop over node u's adjacent nodes
  for(Nbl_itr p = A[u].begin(); p!= A[u].end(); p++) {
    //for(Nbl_itr p = pseudoA[u].begin(); p!= pseudoA[u].end(); p++) { // test for directed graph
    int v = (*p);
    //cout << "v= " << v << endl ; //test
    //printf(" v= %d \n", v); //test
    if(!visited[v])
      DFS(v, visited, Component);
  }
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////




////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Tarjan's Algorithm (named for its discoverer, Robert Tarjan) is a graph theory algorithm for finding 
// the strongly connected components of a graph. Although it precedes it chronologically, it can be seen 
// as an improved version of Kosaraju's algorithm, and is comparable in efficiency to Gabow's algorithm.  
// Here, we have assumed that the graph is connected !!! 
//////////////////////////////////////////////////////////////////////////////////////////////
void Network::SCC_Tarjan()
{
  vector<int>     Vindex(N,-1);       // DFS node number counter 
  vector<int>     Vlowlink(N,0);    
  SCCindex.clear();
  SCCindex.resize(N);

  int index = 0;
  stack<int> S;                       // An empty stack of nodes 
  vector<int> Flag(N,0);              // a flag: tell whether v is in the stack S (this is tricky to make sure that find(S,v) can be done in O(1) time!!)

  //cout << "\n----------------------------------------------\n";
  //cout <<"Get all SCCs using Tarjan's algorithm \n";

  int sccindex = 0;
  SizeofSCC.clear(); // this is important for recalling SCC_Tarjan()
  AllSCCs.clear();   // this is important for recalling SCC_Tarjan()
  for(int v=0; v<N; v++) {
    if(Vindex[v] == -1) {             // start a DFS at each node
      DFS_Tarjan(sccindex, v, index, Vindex, Vlowlink, S, Flag);     // we haven't visited yet
    }
  }
  //cout << "Total " << AllSCCs.size() << " SCCs." << endl;
  Nscc = AllSCCs.size();
  cout << "# of strongly connected components = " << Nscc << endl;
  

  //cout << "\n----------------------------------------------\n";
  //cout << "Now deal with the condensation graph! \n";
  Condensation(); // Why this step is so slow for WWW-ND?
}
//////////////////////////////////////////////////////////////////////////////////////////////




//////////////////////////////////////////////////////////////////////////////////////////////
void Network::DFS_Tarjan(int& sccindex, int v, int& index, vector<int>& Vindex, vector<int>& Vlowlink, stack<int>& S,vector<int>& Flag)
{
  Vindex[v]   = index;                // Set the depth index for v
  Vlowlink[v] = index;
  index++;
  S.push(v);                          // Push v on the stack
  Flag[v] = 1;

 // Consider successors of v
  int u;
  for(Nbl_itr p = Aout[v].begin(); p!= Aout[v].end(); p++) {
    u = (*p);
    if(Vindex[u] == -1) {  // Was successor u=v' visited?   
      DFS_Tarjan(sccindex, u, index, Vindex, Vlowlink, S, Flag);           // Recurse      
      Vlowlink[v] = min(Vlowlink[v], Vlowlink[u]);
    }
    else if(Flag[u]==1) {      // Was successor v' in stack S? 
      Vlowlink[v] = min(Vlowlink[v], Vindex[u]);
    }
  }

  if(Vlowlink[v] == Vindex[v]){   // Is v the root of an SCC?
    Nbl SCC;
    //cout << "SCC" << sccindex << ": "; //test
    //fout << "SCC" << sccindex << ": ";
    do {
      u = S.top(); 
      S.pop(); 
      Flag[u] = 0; 
      SCC.push_back(u);
      SCCindex[u] = sccindex;
      //cout << u << ' ';  //test
      //fout << u << ' ';
    } while (u!=v);
    //cout << endl; //test
    //fout << endl;

    SizeofSCC.push_back(SCC.size()); 
    AllSCCs.push_back(SCC); // save this SCC
    sccindex++;
  }

}
//////////////////////////////////////////////////////////////////////////////////////////////




//////////////////////////////////////////////////////////////////////////////////////////////
void Network::Condensation()
{
  Condensation_N = AllSCCs.size();    // number of SCCs (supernodes in the condensation)
  
  Condensation_A.clear();
  Condensation_Ain.clear();
  Condensation_Aout.clear();

  Condensation_K.clear();
  Condensation_Kin.clear();
  Condensation_Kout.clear();

  Condensation_A.resize(Condensation_N);
  Condensation_Ain.resize(Condensation_N);
  Condensation_Aout.resize(Condensation_N);

  Condensation_K.resize(Condensation_N,0);
  Condensation_Kin.resize(Condensation_N,0);
  Condensation_Kout.resize(Condensation_N,0);

  Condensation_E = 0;


  // Build up the condensation graph, which is a DAG!
  //cout << "Build up the condensation graph." << endl;
  int sccindex = 0;
  SCC_ccindex.clear();
  SCC_ccindex.resize(AllSCCs.size());

  Ngscc = 0; // number of nodes in the giant strongly connected component (size=max)
  for(vector<Nbl>::iterator SCC = AllSCCs.begin(); SCC!=AllSCCs.end(); SCC++) {
    //cout << "SCC " << sccindex << endl;
    int size = (*SCC).size();    
    if(size > Ngscc)
      Ngscc = size;


    Nbl_itr p = (*SCC).begin();
    SCC_ccindex[sccindex] = ccindex[*p]; // the nodes belong to the same SCC must have the same CCindex 
    
    for( ; p!= (*SCC).end(); p++) {
      int u = (*p);
      int SCC_u = SCCindex[u];

      for(Nbl_itr q = Aout[u].begin(); q!= Aout[u].end(); q++) {
	int v = (*q);
	int SCC_v = SCCindex[v];
	if(SCC_v != SCC_u ) { // then SCC_u --> SCC_v
	  if(!find(Condensation_Aout[SCC_u], SCC_v)) // if SCC_v has not been pushed as SCC_u's Aoutlist
	    //cout << SCC_u << "-->" << SCC_v << endl; // debug
	    Condensation_AddDirectedLink(SCC_u, SCC_v);
	}
      }// end of the current node's adjacency list

    }// end of the current SCC
    sccindex++;
  }// end of all SCCs

  // then calculate the layer index of the condensation graph
  //cout << "Calculate the layer index of the condensation graph." << endl;
  //Condensation_GetDAGLayerIndex(fname);
  Condensation_GetDAGLayerIndex();

  // This will be used in Hosoe_GLPK(), i.e. calculating the single-node controllability
  //cout << "Get the descendant list for each SCC! \n";
  Condensation_GetDescendantList();

}
//////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void Network::Condensation_GetDAGLayerIndex()
{
  //cout << "Calculate the layer index! " << endl;
  Condensation_Layer.clear();
  Condensation_Layer.resize(Condensation_N,1);  // initially all vertices are in the lowest layer
  for(int u=0; u<Condensation_N; u++) {
    if(Condensation_Kout[u]==0) {
      for(Nbl_itr q = Condensation_Ain[u].begin(); q!= Condensation_Ain[u].end(); q++) {
	int v = (*q);
	Condensation_UpdateLayerIndex(u, v);
      }
    }
  }


  int TopLayer = 0;
  //cout << "\nLayer index : " << endl;
  for(int u=0; u<Condensation_N; u++) {
    //cout << Condensation_Layer[u] << ' ';
    //fout << u << "  " << Condensation_Layer[u] << endl;
    if(Condensation_Layer[u]>TopLayer)
      TopLayer = Condensation_Layer[u];
  }
  //cout<< "\n with TopLayer = " << TopLayer << endl;

  Layerindex.clear();
  Layerindex.resize(N);
  for(int i=0; i<N; i++) {
    Layerindex[i] = Condensation_Layer[SCCindex[i]];
    //cout << i << "  " << Layerindex[i] << endl; //test
  }


  Condensation_Nlayer = TopLayer;

  Condensation_Layer_width.clear();
  Condensation_Layer_SCCsizevector.clear();
  Condensation_Layer_SCClist.clear();

  Condensation_Layer_width.resize(Condensation_Nlayer+1,0); // number of supernodes in each layer
  Condensation_Layer_SCCsizevector.resize(Condensation_Nlayer+1); // size of supernodes (SCCs) in each layer
  Condensation_Layer_SCClist.resize(Condensation_Nlayer+1); // list of nodes (SCCs) in each layer

  for(int u=0; u<Condensation_N; u++) {
    int l = Condensation_Layer[u];
    Condensation_Layer_width[l]++;
    Condensation_Layer_SCCsizevector[l].push_back(SizeofSCC[u]);
    Condensation_Layer_SCClist[l].push_back(u);
  }

  // calculate the average controllability of the condensation
  // <C> = (W1*1/n + W2*2/n + ... + Wlmax*lmax/n)/n
  //     = (W1*1 + W2*2 + ... + Wlmax*lmax)/n^2
  Condensation_MeanC = 0;
  for(int l=1; l<=TopLayer; l++)   {
    Condensation_MeanC += Condensation_Layer_width[l]*l;
  }
  Condensation_MeanC /= (double)(Condensation_N);
  Condensation_MeanC /= (double)(Condensation_N); // to avoid overflow?


}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////
void Network::Condensation_AddDirectedLink(int SCC_i, int SCC_j)
{
  Link link(SCC_i,SCC_j); // without setting the color of the link
  Condensation_L.push_back(link);
  Condensation_E++;
  
  Condensation_Aout[SCC_i].push_back(SCC_j); 
  Condensation_Ain[SCC_j].push_back(SCC_i); 
  Condensation_A[SCC_i].push_back(SCC_j); 
  Condensation_A[SCC_j].push_back(SCC_i); 
  
  Condensation_Kout[SCC_i]++;
  Condensation_Kin[SCC_j]++;
  Condensation_K[SCC_i]++;
  Condensation_K[SCC_j]++;
}
//////////////////////////////////////////////////////////////////////////////////////////////




////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void Network::Condensation_UpdateLayerIndex(int u, int v)
{
  // if the existence of an edge u <-- v might increase the layer index of v then do it
  if(Condensation_Layer[u]+1 > Condensation_Layer[v]) {
      Condensation_Layer[v] = Condensation_Layer[u]+1;
      
      // and also consider v's ancestors v1 .....
      if(Condensation_Kin[v]>0) { // if we haven't reached the top layer
	for(Nbl_itr q = Condensation_Ain[v].begin(); q!= Condensation_Ain[v].end(); q++) {
	  int v1 = (*q);
	  Condensation_UpdateLayerIndex(v, v1);
	}
      }
  }
  // On the other hand, if the existence of an edge u <-- v can NOT increase the layer index of v 
  // then we needn't update v's layer index.
  // More importantly, we also needn't update v's ancestor's layer indices.
  // This is extremly important to avoid useless recursions!!!!
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// get the list of descendants for all SCCs
void Network::Condensation_GetDescendantList()
{

  //cout << "Build up the descendant list from the bottom to the top ! " << endl;
  Condensation_DescendantList.clear();
  Condensation_DescendantList.resize(Condensation_N); 

  if(Condensation_Nlayer>1) {
  
    // for those SCCs in the first (lowest) layer, they have no descendants according to definition
    // so we start from the second layer 
    int l = 2;
    for(Nbl_itr p = Condensation_Layer_SCClist[l].begin(); p!= Condensation_Layer_SCClist[l].end(); p++) {
      int u = *p;
      for(Nbl_itr q = Condensation_Aout[u].begin(); q!= Condensation_Aout[u].end(); q++) {
	int v = *q;
	//cout << u << "--->" << v << endl; //debug
	Condensation_DescendantList[u].push_back(v);
      }
    }

    if(Condensation_Nlayer>2) {
      for(int l=3; l<=Condensation_Nlayer; l++) {
	for(Nbl_itr p = Condensation_Layer_SCClist[l].begin(); p!= Condensation_Layer_SCClist[l].end(); p++) {
	  int u = *p;
	  for(Nbl_itr q = Condensation_Aout[u].begin(); q!= Condensation_Aout[u].end(); q++) {
	    int v = *q;
	    //cout << u << "--->" << v << endl; //debug
	    Condensation_DescendantList[u].push_back(v);
	    for(Nbl_itr r = Condensation_DescendantList[v].begin(); r!= Condensation_DescendantList[v].end(); r++) {
	      Condensation_DescendantList[u].push_back(*r);
	    }
	    // sort() and unique() to make sure we don't double count descendants
	    Condensation_DescendantList[u].sort();       
	    Condensation_DescendantList[u].unique();
	  }
	}
      }
    }
  }


  /*
  for(int u=0; u<Condensation_N; u++) {
    cout << "SCC" << u << "'s descendant list: " << endl;
    for(Nbl_itr p = Condensation_DescendantList[u].begin(); p!= Condensation_DescendantList[u].end(); p++) {
      cout << *p <<',';
    }
    cout << endl;
  }
  */


}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
