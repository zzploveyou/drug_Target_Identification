#ifndef _NETWORK_H_
#define _NETWORK_H_

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <ctime>
#include <limits.h>
#include <iterator>
#include <sstream>
#include <list>
#include <vector> 
#include <queue> 
#include <stack> 
#include <map> 
#include <algorithm>

#include <glpk.h>      // use GNU Linear Programming Kit (GLPK)

#include "tool.h"
#include "Link.h"


typedef list<int> Nbl; // neighbor list
typedef Nbl::iterator Nbl_itr;


class Network
{
 public:
  Network();
  ~Network();

  void AddDirectedLink(int i, int j);
  void AddDirectedWeightedLink(int i, int j);
  inline int edgeindex(int i, int j);

  void Read_StandardNodemap(char* fname1);
  void Read_StandardElist(char* fname1);


  /////////////////////////////////////////////////////////////////////////////////////////////////
  void DFS();
  void DFS(int u, vector<bool>& visited, Nbl&  Component);
  void SCC_Tarjan();
  void DFS_Tarjan(int& sccindex, int v, int& index, vector<int>& Vindex, vector<int>& Vlowlink, stack<int>& S,vector<int>& Flag);

  void Condensation_AddDirectedLink(int SCC_i, int SCC_j);
  void Condensation_GetDAGLayerIndex();
  void Condensation_UpdateLayerIndex(int u, int v);
  void Condensation_GetDescendantList();

  void Condensation(char* fname);
  void Condensation();
  void OutputCondensation(char* fname);
  void OutputCondensation_wofl(char* fname);
  void OutputCondensation_layers(char* fname);


  /////////////////////////////////////////////////////////////////////////////////////////////////
  void Hosoe_GLPK(char* fname);

  void MarkRedundantLeaves();
  void Gprime_Build(int I);
  void Gprime_Clear();
  void Gprime_AddDirectedLink(int i, int j, bool flag);
  void Modify_Gprime_LP(int I, int J, glp_prob *lp);
  void UpdateEin(int i, glp_prob *lp);
  void UpdateEout(int i, glp_prob *lp);
  /////////////////////////////////////////////////////////////////////////////////////////////////


 private:
  int N;     // current number of nodes
  vector<string> NodeName; //  name is a string     
  map<string,int> NodeMAP; // the map between the nodename and the nodex index i

  int E;     // number of edges (or links)
  vector<Link>  L;
  map<string,int> MAP; // the map between (i,j) and the edge index e

  vector<Nbl>   A; // Adjacency list
  vector<Nbl>   Aout;   // Adjacency output list
  vector<Nbl>   Ain;    // Adjacency input list

  vector<int>   Kin;   // in-degree of each node
  vector<int>   Kout;  // out-degree of each node
  vector<int>   K;  // degree of each node

  
  /////////////////////////////////////////////////////
  double        Kmin;
  double        Kmax;
  double        K1inversemean; //  < 1/(K+1)>
  double        logK1mean;     //  <log(K+1)>
  double        Ksrmean;       //  <K^0.5>
  double        Kmean;         //  <K>
  double        K2mean;        //  <K^2>
  double        Kvar;          //  <K^2>-<K>^2
  /////////////////////////////////////////////////////


  /////////////////////////////////////////////////////////////////////////////////////////////////
  int Ncc; // # of connected components
  vector<Nbl>  AllComponents; // connected component
  double Condensation_MeanC; 


  list<int> LClist; // the vertex list of the largest component

  // To build a mapping between indices: we use the following two vertors
  // OriginalIndexof[i] give the original index of the largest component's i-th node 
  vector<int>  OriginalIndexofLCCnode;
 
  // LCCIndexof[i] give the in-largest-component index of the original network's i-th node
  vector<int>  LCCIndexofOriginalnode; // if IndexinLC[i] = -1, this means it doesn't belong to the lc
  // otherwise, its value just gives the index

  vector<bool> LC; // whether the node belongs to the largest component
  int          lcc_index; // the index of the largest component
  int          Nlc; // number of nodes in the largest connected component
  double       Nac; // average size of connected components

  double       nsolo;
  double       nlc; // :=Nlc/N
  int          Elc; // number of edges in the largest connected component
  double       mlc; // edge density for the largest connected component 


  int          Kmaxlc; // the highest degree in the largest connected component
  int          leader; // we choose the leader to be the node with highest degree (within the largest connected component, of course)

  
  vector<int>  ccindex; // which connected component each node belongs to 
  vector<int>  SCC_ccindex; // which connected component each SCC belongs to 
  

  int Nscc;             // the total # of scc
  int Ngscc;            // the size of the giant SCC
  vector<Nbl>  AllSCCs; // the list of all strongly connected components
  vector<int>  SizeofSCC; // the size of each SCC
  double SmeanofSCC;      // mean SCC size 
  double S2meanofSCC;     // mean SCC size^2

  vector<int>     CsmaxofLayer; // the maximum Cs of nodes inside each Layer of the largest CC 
  vector<int>     CsminofLayer; // the minimum Cs of nodes inside each Layer of the largest CC
  vector<double>  CsaveofLayer; // the average Cs of nodes inside each Layer of the largest CC
  vector<int>     WidthofLayer;     // the # of nodes  inside each Layer of the largest CC

  vector<Nbl>   Condensation_A; // Adjacency list
  vector<Nbl>   Condensation_Aout;   // Adjacency output list of the Condensation
  vector<Nbl>   Condensation_Ain;    // Adjacency input list of the Condensation

  vector<int>   Condensation_K; // degree of each node
  vector<int>   Condensation_Kin;   // in-degree of each node of the Condensation
  vector<int>   Condensation_Kout;  // out-degree of each node of the Condensation

  vector<int>   SCCindex;          // which SCC the node i belongs to
  vector<int>   Layerindex;        // which layer the node i belongs to 
  
  vector<Link>  Condensation_L;
  int Condensation_N;    // number of nodes
  int Condensation_E;    // number of edges (or links)

  // The topological ordering for the condensation graph, which is definitely a directed acyclic graph (DAG), so it is meaningful
  Nbl Condensation_TopologicalOrdering; 


  int Condensation_Nlayer;               // total number of layers
  vector<int>                Condensation_Layer_width; // number of nodes (SCCs) in each layer
  vector< vector<double> >   Condensation_Layer_SCCsizevector; // size of nodes (SCCs) in each layer
  vector<Nbl>                Condensation_Layer_SCClist; // list of nodes (SCCs) in each layer


  vector<int>   Condensation_Layer;        // layer index of each node (SCC)
  vector<Nbl>   Condensation_AncestorList; // ancestor list of each node (SCC)
    
  vector<Nbl>   Condensation_DescendantList; // descendant list of each node (SCC)

  vector< vector<int> >   ReachableRoot; // for each node, it can be reached from at least one root node (actuator)
  vector<int> Naccessible;      // for each actuator, we record its influence range, i.e. how many accessible nodes
  // for non-actuator, we set its influence range to be one.
  // This is used to draw the actuator node with the size proptional 
  // to its influence range     
  /////////////////////////////////////////////////////////////////////////////////////////////////


  /////////////////////////////////////////////////////////////////////////////////////////////////
  vector<bool> BelongtoGprime; // whether a node belongs to the new graph G'(A,B) 
  vector<bool> RedundantLeave; // whether this is a redundant leave node in the original G(A)

  // To build a mapping between indices in G(A) and indices in the accessible subgraph of G'(A,B),
  // we use the following two vertors
  vector<int> GprimeIndexofOriginalnode; 
  vector<int> OriginalIndexofGprimenode;

  // Here are parameters for the G' graph constructed from G(A,B) (in applying the Hosoe's theorem)
  int Gprime_N;                // number of nodes
  int Gprime_E;                // number of edges 

  vector<Link>  Gprime_L;
  vector<bool>  BelongtoG;     // flag: tell whether this link belong to G(A,B), index starts from 1

  vector<Nbl>   Gprime_Eout;   // outgoing edge list of the Gprime
  vector<Nbl>   Gprime_Ein;    // incoming edge list of the Gprime

  vector<double> Cc;           // single-node structural controllability:= dc/N
  double Cc_avg;

  vector<int>    dc;           // generic dimension of single-node structural controller

  /////////////////////////////////////////////////////////////////////////////////////////////////

    
};


inline int Network::edgeindex(int i, int j)
{
  stringstream sst; sst << i << ">" << j;
  return MAP[sst.str()];
}


void Parser_s2n(char* fname1);


#endif /* _NETWORK_H_ */

