#ifndef _MYNR_H_
#define _MYNR_H_

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <iomanip>
#include <string>
#include <list>
#include <vector>
#include <set>
#include <stack>
#include <deque>
#include <limits>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>


using namespace std;

const double EPS = numeric_limits<double>::epsilon(); 
const double SMALL = numeric_limits<double>::min()/numeric_limits<double>::epsilon();


typedef list<int> Nbl; // neighbor list

void mynrerror(const string error_text);
int* ivector(int nl, int nh);
double* dvector(int nl, int nh);
void free_ivector(int* v, int nl, int nh);
void free_dvector(double* v, int nl, int nh);

bool find(vector<set<int> >& Vset, set<int>& s);
bool find(vector< vector<char>  >& Vstate, vector<char>& state);
bool find(vector< vector<int> >& Vv, vector<int>& v);
bool find(vector< vector<string> >& Vs, vector<string>& v);


bool find(set<int>& nbl, int j);

bool find(Nbl& nbl, int j);
int findpos(Nbl& nbl, int j);

bool find(vector<int>& nbv, int j);
int findpos(vector<int>& nbv, int j);

bool find(vector<string>& nbs, string s);
int findpos(vector<string>& nbs, string s);

bool find(deque<int>& S, int x);
void print(deque<int>& Q);




// Makes directory "data" and "data/average", both under Unix and Windows
void MakeDirectories();
void MakeDirectories(double m);
void MakeDirectories(string file);
void MakeDirectory(string path, int type);
void MakeDirectory(string path, double p);

void MakeDirectory(string file);
void MakeDirectories(char* file);
void MakeDirectories(char* file, int seed);

//void MakeDirectories(int L);


#endif /* _MYNR_H_ */
