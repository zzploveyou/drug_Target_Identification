#include "Network.h"


///////////////////////////////////////////////////////////////
// default constructor
Network::Network()
{
  N  = 1;
  E  = 0;
}

Network::~Network()
{
}
///////////////////////////////////////////////////////////////



///////////////////////////////////////////////////////////////
void Network::AddDirectedLink(int i, int j)
{
  if(!find(Aout[i],j)) {
    //cout << i << "-->" << j << endl; //test
    //cout << NodeName[i] << "-->" << NodeName[j] << endl; //test

    Link link(i, j, E+1); 
    L.push_back(link);

    // build a mapping between the edge (i,j) and the edge index e
    stringstream sst; 
    sst << i << ">" << j;  

    if(MAP[sst.str()]==0) // Note that if an edge (i,j) has already been mapped to an index, then we skip this step
      MAP[sst.str()] = E;
   
    E++;
  
    Aout[i].push_back(j); 
    Ain[j].push_back(i); 
    Kout[i]++;
    Kin[j]++;
    K[i]++;
    K[j]++;


    if(!find(A[i],j)) {
      A[i].push_back(j); 
      A[j].push_back(i); 
    }
  }

}
///////////////////////////////////////////////////////////////



/////////////////////////////////////////////////////////////////////////////////////////////////
void Parser_s2n(char* fname1)
{
  ifstream fin(fname1, ios_base::in);
  if(!fin) {cout << "Cannot open " << fname1 << " for read."; exit(0);}

  char fname2[256];
  sprintf(fname2, "%s.nodemap", fname1);
  ofstream fout(fname2, ios_base::out);
  if(!fout) {cout << "Cannot open " << fname2 << " for write."; exit(0);}

  char fname[256];
  sprintf(fname, "%s.elist.t", fname1);
  ofstream tout(fname, ios_base::out);
  if(!tout) {cout << "Cannot open " << fname << " for write."; exit(0);}

  sprintf(fname, "%s.elist.b", fname1);
  ofstream bout(fname, ios_base::out|ios::binary);
  if(!bout) {cout << "Cannot open " << fname << " for write."; exit(0);}

  // do the index mapping first
  vector<string> nodenamelist; //  name is a string (could be words, not just number)
  string source; 
  string target;
  while (fin >> source >> target) {
    if(!find(nodenamelist, source)) {
      nodenamelist.push_back(source);
    }
    if(!find(nodenamelist, target)) {
      nodenamelist.push_back(target);
    }
  }
  fin.close();

  // save the nodemap file
  int n = nodenamelist.size();
  map<string,int> MAP; // save the map between nodename and the index
  for(int i=0; i<n; i++) {
    fout << i << ' ' << nodenamelist[i] << endl;
    MAP[nodenamelist[i]] = i;
  }

  // read the data again
  ifstream fin2(fname1, ios_base::in);
  if(!fin2) {cout << "Cannot open " << fname1 << " for read."; exit(0);}

  vector< set<int> > aoutlist(n);
  while (fin2 >> source >> target) {
    int i = MAP[source];
    int j = MAP[target];
    aoutlist[i].insert(j); // using set<int> will avoid getting repeated links
  }
  fin2.close();
  
  int m = 0;
  for(int i=0; i<n; i++) {
    m += aoutlist[i].size();
  }
  

  // save the standard edgelist file
  // Note that the first two lines store the information of N and E !!
  cout << fname1 << "\n# N= " << n << ", E= " << m << endl;
  tout << "#N= " << n << endl;
  tout << "#E= " << m << endl;

  int* nm = new int [2];
  nm[0]=n; nm[1]=m;
  bout.write(reinterpret_cast<char *>(nm), 2*sizeof(int));
  delete [] nm;
  int* endpoints = new int [2*m];
  int e=0;
  for(int i=0; i<n; i++) {
    for(set<int>::iterator it=aoutlist[i].begin(); it!=aoutlist[i].end(); it++) {
      int j = (*it);
      endpoints[e*2+0]=i;
      endpoints[e*2+1]=j;
      e++;
      tout << i << ' ' << j << endl;
    }
  }
  bout.write(reinterpret_cast<char *>(endpoints), 2*m*sizeof(int));
  delete [] endpoints;

  fout.close();
  tout.close();
  bout.close();
}
/////////////////////////////////////////////////////////////////////////////////////////////////



///////////////////////////////////////////////////////////////////////////////
// Here, read the standard elist file (obtained from the parser), 
// note that in the standard elist file, node index must start from 0, end in n-1 
// and the first line stores the information of n and m
void Network::Read_StandardElist(char* fname1)
{
  char fname[256];
  sprintf(fname, "%s.elist.b", fname1);
  ifstream bin(fname, ios_base::in|ios::binary);
  if(!bin) {cout << "Cannot open " << fname << " for read."; exit(0);}

  //sprintf(fname, "%s.elist.t.copy", fname1);
  //ofstream tout(fname, ios_base::out|ios::binary);
  //if(!tout) {cout << "Cannot open " << fname << " for write."; exit(0);}

  int* nm = new int [2];
  bin.read(reinterpret_cast<char *>(nm), 2*sizeof(int));
  int n = nm[0];
  int m = nm[1];
  delete [] nm;

  cout << "Read Standard Elist:\n";
  cout << "N= " << n << endl;
  cout << "E= " << m << endl;
  //tout << "#N= " << n << endl;
  //tout << "#E= " << m << endl;

  int* endpoints = new int [2*m];
  bin.read(reinterpret_cast<char *>(endpoints), 2*m*sizeof(int));
  bin.close();
  ////////////////////////////////////////////////////////////////////////

  N = n;

  A.resize(N);
  Ain.resize(N);
  Aout.resize(N);

  K.resize(N,0);
  Kin.resize(N,0);
  Kout.resize(N,0);


  int i, j;
  E = 0;
  for(int e=0; e<m; e++) {
    //cout << endpoints[2*e+0] << ' ' << endpoints[2*e+1] << endl; //test
    //tout << endpoints[2*e+0] << ' ' << endpoints[2*e+1] << endl; //test
    i = endpoints[2*e+0]; // source
    j = endpoints[2*e+1]; // target

    if(i>=N || j>=N) {//debug
      cout << i << ' ' << j << endl;
      cout << "error! " << endl;
      exit(0);
    }

    if(!find(Aout[i],j)) {
      AddDirectedLink(i, j);  
      //cout << i << ' ' << j << endl; //test
    }
    else {
      cout << "avoid multiple edge: " << i << "-->" << j << endl;
    }
  }
  delete [] endpoints;
  
  //tout.close();
  //cout << "N= " << N << endl;
  //cout << "E= " << E << endl;
  //exit(0);
}
///////////////////////////////////////////////////////////////////////////////





///////////////////////////////////////////////////////////////////////////////
void Network::Read_StandardNodemap(char* fname1)
{
  char fname[256];
  sprintf(fname, "%s.nodemap", fname1);
  ifstream fin(fname, ios_base::in);
  if(!fin) {cout << "Cannot open " << fname << " for read."; exit(0);}

  int i;
  string nodename;
  NodeName.clear();
  while (fin >> i >> nodename) {
    NodeName.push_back(nodename);
    NodeMAP[nodename]=i;
  }
  fin.close();
}
///////////////////////////////////////////////////////////////////////////////


