#include <iostream>
#include <fstream>
#include "Network.h" 
#include "timer.h"
#include "tool.h"

using namespace std;


int main(int argc, char** argv)
{
  if(argc!=3)
    {
      cout << "\nNumber of arguments is incorrect!\n";
      cout << "\nCommand format: ./CalControlCentrality  path file\n";

      exit(0);
    }

  string  path   = argv[1];
  string  edgefile = argv[2];

  MakeDirectories();
  timer time;
  time.start();

  char fname1[256];
  sprintf(fname1, "%s/%s", path.c_str(), edgefile.c_str());
  cout << "\n\n-------- Parsing original edgelist file"<< fname1 << endl;
  Parser_s2n(fname1); 

  char elistfile[256];
  sprintf(elistfile, "%s/%s.elist.b", path.c_str(), edgefile.c_str());
  cout << "\n\n-------- Reading standard elist file "<< elistfile << endl;
  Network network;
  network.Read_StandardNodemap(fname1);
  network.Read_StandardElist(fname1); 

  char fname2[256];
  sprintf(fname2, "./data/%s", edgefile.c_str());
  cout << "\n\n-------- Calculate control centrality of each node.  "<< endl;
  network.DFS();  
  network.SCC_Tarjan();
  network.Hosoe_GLPK(fname2); 

  cout << "In total it takes " << time << " s.\n\n";

  exit(1);
}


