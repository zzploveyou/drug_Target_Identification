
#include <iostream>
#include <string>
#include "tool.h"

using namespace std;
const double DBL_MAX = numeric_limits<double>::max();
const double DBL_MIN = numeric_limits<double>::min();


inline void mynrerror(const string error_text)
{
  cout << "Numerical Recipes run-time error..." << endl;
  cout << error_text << endl;
  cout << "...now exiting to system..." << endl;
  exit(1);
}


///////////////////////////////////////////////////////////////////////
int* ivector(int nl, int nh)
{
  int *v;
  v = new int [nh-nl+1];
  if (!v) mynrerror("allocation failure in ivector()");
  return v-nl;
}

double* dvector(int nl, int nh)
{
  double* v = new double [nh-nl+1];
  if (!v) mynrerror("allocation failure in dvector()");
  return v-nl;
}

void free_ivector(int* v, int nl, int nh)
{
  v += nl;
  delete [] v;
}

void free_dvector(double* v, int nl, int nh)
{
  v += nl;
  delete [] v;
}
///////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////////////////////////
// find whether the element j is in the list nbl
bool find(Nbl& nbl, int j)
{
  for(Nbl::iterator p = nbl.begin(); p!= nbl.end(); p++) {
    if(j==(*p)) 
      return true;
  }
    
  return false;
}
/////////////////////////////////////////////////////////////////////////////////////////////////



/////////////////////////////////////////////////////////////////////////////////////////////////
bool find(set<int>& nbl, int j)
{
  for(set<int>::iterator p = nbl.begin(); p!= nbl.end(); p++) {
    if(j==(*p)) 
      return true;
  }
    
  return false;
}
/////////////////////////////////////////////////////////////////////////////////////////////////



/////////////////////////////////////////////////////////////////////////////////////////////////
bool find(vector<set<int> >& Vset, set<int>& S)
{
  for(vector<set<int> >::iterator p = Vset.begin(); p!= Vset.end(); p++) {
    if(S==(*p)) 
      return true;
  }
    
  return false;
}
/////////////////////////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////////////////////////
// find whether the element j is in the list nbl
bool find(vector<vector<int> >& Vv, vector<int>& v)
{
  for(vector<vector<int> >::iterator p = Vv.begin(); p!= Vv.end(); p++) {
    if(v==(*p)) 
      return true;
  }
    
  return false;
}
/////////////////////////////////////////////////////////////////////////////////////////////////



/////////////////////////////////////////////////////////////////////////////////////////////////
// find whether the element j is in the list nbl
bool find(vector<vector<string> >& Vs, vector<string>& v)
{
  for(vector<vector<string> >::iterator p = Vs.begin(); p!= Vs.end(); p++) {
    if(v==(*p)) 
      return true;
  }
    
  return false;
}
/////////////////////////////////////////////////////////////////////////////////////////////////




/////////////////////////////////////////////////////////////////////////////////////////////////
// find whether the state s is in the state pool
bool find(vector< vector<char>  >& Vstate, vector<char>& state)
{
  for(vector< vector<char> >::iterator p = Vstate.begin(); p!= Vstate.end(); p++) {
    if(state==(*p)) 
      return true;
  }
    
  return false;
}
/////////////////////////////////////////////////////////////////////////////////////////////////




/////////////////////////////////////////////////////////////////////////////////////////////////
// find whether the element j is in the vector nbv
bool find(vector<int>& nbv, int j)
{
  int n = nbv.size();
  for(int i=0; i<n; i++)
    if(j==nbv[i]) 
      return true;

  return false;
}
/////////////////////////////////////////////////////////////////////////////////////////////////



/////////////////////////////////////////////////////////////////////////////////////////////////
// find whether the element j is in the vector nbv
bool find(vector<string>& nbs, string s)
{
  int n = nbs.size();
  for(int i=0; i<n; i++)
    if(s==nbs[i]) 
      return true;

  return false;
}
/////////////////////////////////////////////////////////////////////////////////////////////////



/////////////////////////////////////////////////////////////////////////////////////////////////
// find whether the element x is in the deque Q
bool find(deque<int>& Q, int x)
{
  for(deque<int>::iterator q = Q.begin(); q!= Q.end(); q++) {
    if(x==(*q)) 
      return true;
  }
  
  return false;
}
/////////////////////////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void print(deque<int>& Q) 
{
  for(deque<int>::iterator q = Q.begin(); q!= Q.end(); q++) 
    cout << (*q) << "-->";
  cout << endl;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////////////////////////
// find the position of the element j in the list nbl  (assume j is definitely in the list)
int findpos(Nbl& nbl, int j)
{
  int pos=0;
  for(Nbl::iterator p = nbl.begin(); p!= nbl.end(); p++) {
    if(j==(*p)) 
      return pos;
    else
      pos++;
  }

  return -1;
}
/////////////////////////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////////////////////////
// find the position of the element j in the vector nbv  (assume j is definitely in the vector)
int findpos(vector<int>& nbv, int j)
{
  int n = nbv.size();
  for(int i=0; i<n; i++)
    if(j==nbv[i]) 
      return i;
  
  return -1;
}
/////////////////////////////////////////////////////////////////////////////////////////////////



/////////////////////////////////////////////////////////////////////////////////////////////////
// find the position of the element j in the vector nbv  (assume j is definitely in the vector)
int findpos(vector<string>& nbs, string s)
{
  int n = nbs.size();
  for(int i=0; i<n; i++)
    if(s==nbs[i]) 
      return i;
  
  return -1;
}
/////////////////////////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////////////////////////
// return the element in the list nbl with a given position (index)
int print(Nbl& nbl)
{
  Nbl::iterator p = nbl.begin();
  cout << *p;
  p++;
  for(; p!= nbl.end(); p++) {
    cout << "-->" << *p;
  }
  cout << endl;

  return 1;
}
/////////////////////////////////////////////////////////////////////////////////////////////////




void MakeDirectories()
{
    struct stat s;
    if (-1==stat("data",&s))
    {
	int  err = system("mkdir data");
	if (err == -1) 
	    cout << "Failed to create directory data " <<endl;
    }
}


void MakeDirectories(double m)
{
    struct stat s;
 
    char temp [256];
    sprintf(temp, "data/m%.3lf/", m);
    char cmd [256];
    sprintf(cmd, "mkdir %s", temp);

   if (-1==stat(temp,&s))
    {
	int  err = system(cmd);
	if (err == -1) 
	    cout << "Failed to create dir " << temp << endl;
    }
}




// for real data analysis
void MakeDirectory(string path, int type)
{
  struct stat s;
  
  char temp [256];
  sprintf(temp, "%s/rand%d", path.c_str(), type);
  char cmd [256];
  sprintf(cmd, "mkdir %s", temp);
  if (-1==stat(temp,&s)) {
    int  err = system(cmd);
    if (err == -1) 
      cout << "Failed to create dir " << temp << endl;
  }

}


// for real data analysis
void MakeDirectory(string path, double p)
{
  struct stat s;
  
  char temp [256];
  sprintf(temp, "%s/p%.3lf", path.c_str(), p);
  char cmd [256];
  sprintf(cmd, "mkdir %s", temp);
  if (-1==stat(temp,&s)) {
    int  err = system(cmd);
    if (err == -1) 
      cout << "Failed to create dir " << temp << endl;
  }

}


// for real data analysis
void MakeDirectory(string file)
{
  struct stat s;

  char temp [256];
  sprintf(temp, "data-%s/", file.c_str());
  char cmd [256];
  sprintf(cmd, "mkdir %s", temp);
  if (-1==stat(temp,&s)) {
    int  err = system(cmd);
    if (err == -1) 
      cout << "Failed to create dir " << temp << endl;
  }

}


// for real data analysis
void MakeDirectories(string file)
{
  struct stat s;
  /*
  if (-1==stat("data",&s))  {
    int  err = system("mkdir data");
    if (err == -1) 
      cout << "Failed to create directory data " <<endl;
  }
  */
  
  char temp [256];
  sprintf(temp, "data-%s/", file.c_str());
  char cmd [256];
  sprintf(cmd, "mkdir %s", temp);
  if (-1==stat(temp,&s)) {
    int  err = system(cmd);
    if (err == -1) 
      cout << "Failed to create dir " << temp << endl;
  }


  sprintf(temp, "data-%s/Real/", file.c_str());
  sprintf(cmd, "mkdir %s", temp);
  if (-1==stat(temp,&s)) {
    int  err = system(cmd);
    if (err == -1) 
      cout << "Failed to create dir " << temp << endl;
  }
  

  sprintf(temp, "data-%s/Rand0/", file.c_str());
  sprintf(cmd, "mkdir %s", temp);
  if (-1==stat(temp,&s)) {
    int  err = system(cmd);
    if (err == -1) 
      cout << "Failed to create dir " << temp << endl;
  }


  sprintf(temp, "data-%s/Rand1/", file.c_str());
  sprintf(cmd, "mkdir %s", temp);
  if (-1==stat(temp,&s)) {
    int  err = system(cmd);
    if (err == -1) 
      cout << "Failed to create dir " << temp << endl;
  }


  sprintf(temp, "data-%s/Rand2/", file.c_str());
  sprintf(cmd, "mkdir %s", temp);
  if (-1==stat(temp,&s)) {
    int  err = system(cmd);
    if (err == -1) 
      cout << "Failed to create dir " << temp << endl;
  }


}



// for synthetic data analysis
void MakeDirectories(char* file)
{
    struct stat s;

    
    if (-1==stat("data",&s))  {
      int  err = system("mkdir data");
      if (err == -1) 
	cout << "Failed to create directory data " <<endl;
    }
    
    char temp [256];
    sprintf(temp, "data/%s", file);
    char cmd [256];
    sprintf(cmd, "mkdir %s", temp);

   if (-1==stat(temp,&s))
    {
	int  err = system(cmd);
	if (err == -1) 
	    cout << "Failed to create dir " << temp << endl;
    }
}


// for synthetic data analysis
void MakeDirectories(char* file, int seed)
{
    struct stat s;

    char temp [256];
    sprintf(temp, "data/%s/seed%d/", file,seed);
    char cmd [256];
    sprintf(cmd, "mkdir %s", temp);

   if (-1==stat(temp,&s))
    {
	int  err = system(cmd);
	if (err == -1) 
	    cout << "Failed to create dir " << temp << endl;
    }
}


