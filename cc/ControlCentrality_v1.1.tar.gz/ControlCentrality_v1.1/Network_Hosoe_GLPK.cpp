#include "Network.h"
#include <glpk.h>                // use GNU Linear Programming Kit (GLPK)

//////////////////////////////////////////////////////////////////////////////////////////////////
void Network::Gprime_AddDirectedLink(int i, int j, bool flag)
{
  Gprime_E++;

  // record the outgoing and incoming edge lables for each node 
  Gprime_Eout[i].push_back(Gprime_E);
  Gprime_Ein[j].push_back(Gprime_E);
  //cout << "edge-" << Gprime_E << "   :   " << OriginalIndexofGprimenode[i] << "-->" << OriginalIndexofGprimenode[j] <<   endl;  // debug

  Link link(i, j, Gprime_E); 
  Gprime_L.push_back(link);
  BelongtoG.push_back(flag);
}
//////////////////////////////////////////////////////////////////////////////////////////////////



//////////////////////////////////////////////////////////////////////////////////////////////////
// update rows associated with node-i's incoming edges in the constraint matrix of the linear program
// (Note that i is the index in G' rather than the index in G(A))
void Network::UpdateEin(int i, glp_prob *lp)
{
  int row = 2*i+1;
  int length = Gprime_Ein[i].size();

  int*    index = ivector(1,length);
  double* value = dvector(1,length);
  int k = 1;
  for (Nbl_itr p = Gprime_Ein[i].begin(); p!=Gprime_Ein[i].end(); p++,k++) {
    index[k] = (*p);
    value[k] = 1.0;
  }
  glp_set_mat_row(lp, row, length, index, value);

  free_ivector(index, 1, length);
  free_dvector(value, 1, length);
  
}
//////////////////////////////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////////////
// update rows associated with node-i's outgoing edges in the constraint matrix of the linear program
// (Note that i is the index in G' rather than the index in G(A))
void Network::UpdateEout(int i, glp_prob *lp)
{
  int row = 2*i+2;
  int length = Gprime_Eout[i].size();

  int*    index = ivector(1,length);
  double* value = dvector(1,length);
  int k = 1;
  for (Nbl_itr p = Gprime_Eout[i].begin(); p!=Gprime_Eout[i].end(); p++,k++) {
    index[k] = (*p);
    value[k] = 1.0;
  }
  glp_set_mat_row(lp, row, length, index, value);

  free_ivector(index, 1, length);
  free_dvector(value, 1, length);
  
}
///////////////////////////////////////////////////////////////////////////////////////



//////////////////////////////////////////////////////////////////////////////////////////////////
void Network::Gprime_Clear()  
{
  for(int i=0; i< Gprime_N; i++) {
    Gprime_Eout[i].clear();
    Gprime_Ein[i].clear();

  }
  Gprime_Eout.clear();
  Gprime_Ein.clear();
  
  Gprime_E = 0;

  BelongtoG.clear();
  Gprime_L.clear();
  BelongtoGprime.clear();
  GprimeIndexofOriginalnode.clear();
  OriginalIndexofGprimenode.clear();
  
}
///////////////////////////////////////////////////////////////////////////////////////////////////



//////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// The following functions are used to calculate dc of single-node control for all the nodes in a for-loop.
// 
//////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////
// construct the new graph G' based on G(A,B), the controlling node is given
// ATTENTION: G(A,B) must be reachable, this means those inreachable nodes in the original network 
//            should NOT be considered in the current G(A,B).
//            We should use the condensation graph built by SCC decomposition as a guide.
// 
// for single-node control only 
void Network::Gprime_Build(int u)  
{
  ////////////////////////////////////////////////////////////////////////////////////////////
  // first build the RSCC (reachable SCC) list
  Nbl  RSCClist; // the list of all reachable SCCs (RSCC) from the controlling node

  int SCC_u = SCCindex[u];
  RSCClist.push_back(SCC_u);
    
  for(Nbl_itr q = Condensation_DescendantList[SCC_u].begin(); q!= Condensation_DescendantList[SCC_u].end(); q++) {
    RSCClist.push_back(*q);
  }
  ////////////////////////////////////////////////////////////////////////////////////////////


  ////////////////////////////////////////////////////////////////////////////////////////////
  // now count how many nodes in those RSCCs, defined to be Naccessible
  BelongtoGprime.resize(N, false);
  int Naccessible = 0; 
  for (Nbl_itr p = RSCClist.begin(); p!=RSCClist.end(); p++) {
    int SCC_u = *p;

    for (Nbl_itr q = AllSCCs[SCC_u].begin(); q!=AllSCCs[SCC_u].end(); q++) {
      int I = *q;
      
      if(!RedundantLeave[I]) {
	BelongtoGprime[I] = true;
	Naccessible++;
	//cout << I << endl; //debug
      }
    }
  }
  //cout << "Naccessible = " << Naccessible << endl;
  ////////////////////////////////////////////////////////////////////////////////////////////


  ////////////////////////////////////////////////////////////////////////////////////////////
  // We need to respect the mapping between the two sets of indices.
  // Here I, J are the indices in the original network G(A)
  //      i, j are the indices in the reachable subgraph of G'(A,B)
  // We consider only those reachable nodes in the original network.
  // Those nodes in G' are labeled with vector BelongtoGprime[i]=1.
  // We need a mapping between the two sets of indices.
  // This mapping is done by using the following two vertors: 
  GprimeIndexofOriginalnode.resize(N,-1);             // -1 means that this node does NOT belong to G'
  OriginalIndexofGprimenode.resize(Naccessible+1, -1);  // -1 means that this node does NOT belong to G(A) at all
                                                 
  int i=0;
  for(int I=0; I<N; I++) {
    if(BelongtoGprime[I]) {
      //cout << "I= " << I << endl; //debug
      GprimeIndexofOriginalnode[I] = i;
      OriginalIndexofGprimenode[i] = I;
      i++;
    }
  }

  // the origin belong to G(B) rather than G(A)
  OriginalIndexofGprimenode[Naccessible] = N;
  ////////////////////////////////////////////////////////////////////////////////////////////


  ////////////////////////////////////////////////////////////////////////////////////////////
  // now build the new graph G'
  int r = 1;
  Gprime_N = Naccessible + 1;
  //cout << "Gprime_N = " << Gprime_N << endl;

  Gprime_Ein.resize(Gprime_N);
  Gprime_Eout.resize(Gprime_N);

  Gprime_E=0;

  // just to make BelongtoG's index start from 1, so we push a value for the zero-th element
  BelongtoG.push_back(false); 

  // just to make Gprime_L's index start from 1, so we push a value for the zero-th element
  Link link(0, 0, 0); 
  Gprime_L.push_back(link);


  for (Nbl_itr p = RSCClist.begin(); p!=RSCClist.end(); p++) {
    int SCC_u = *p;

    for (Nbl_itr q = AllSCCs[SCC_u].begin(); q!=AllSCCs[SCC_u].end(); q++) {
      int I = *q;
      if(RedundantLeave[I])  
	continue;
	
      // if I is NOT a redundant leave
      int i = GprimeIndexofOriginalnode[I];
      if(Kout[I]>0) {
	for (Nbl_itr s = Aout[I].begin(); s!=Aout[I].end(); s++) {
	  int J= *s;
	  if(!RedundantLeave[J]) { // if J is NOT a redundant leave
	    int j = GprimeIndexofOriginalnode[J];
	    Gprime_AddDirectedLink(i, j, true);
	  }
	}
	
	if(!find(Aout[I],I)) {
	  Gprime_AddDirectedLink(i, i, false);
	}
      }
      else {
	Gprime_AddDirectedLink(i, i, false);
      }
	
      Gprime_AddDirectedLink(i, Naccessible, false);
    }// end of loop within a RSCC
  }// end of loop over all RSCCs  

  Gprime_AddDirectedLink(Naccessible, Naccessible, false);    
  
  int J = u;
  int j = GprimeIndexofOriginalnode[J];
  Gprime_AddDirectedLink(Naccessible, j, true);

  //cout << "Gprime_E = " << Gprime_E << endl; //test

}
///////////////////////////////////////////////////////////////////////////////////////



//////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////
// here, redundant structural equivalent leaves in the original network G(A) are trimmed (marked) 
// (only one of them is kept). because they are redundant in the calculation of dc.
// Moreover, the size of G' will NOT be that large so we can speed up the SIMPLEX calculation.
void Network::MarkRedundantLeaves()  
{
  // consider all the SCCs in the first layer
  for(Nbl_itr p = Condensation_Layer_SCClist[1].begin(); p!= Condensation_Layer_SCClist[1].end(); p++) {
    int SCC_u = *p;

    if(SizeofSCC[SCC_u]==1) {
      int I0 = *AllSCCs[SCC_u].begin();
      
      // if node I0 is a leave node and it is not redundant  
      // (note that Kout[I0]==0 is obvious for first-layer SCCs with size=1)
      if(Kin[I0]==1 && !RedundantLeave[I0]) {
	cout << "leaf node " << NodeName[I0] << endl; //debug
	int J = *Ain[I0].begin();
	if(Kout[J]>1) {
	  for(Nbl_itr q = Aout[J].begin(); q!= Aout[J].end(); q++) {
	    int I = *q;
	    if(I!=I0 && Kout[I]==0 && Kin[I]==1) { // then node I is structural equivalent to I0, i.e. it is redundant
	      if(!RedundantLeave[I]) { // if not marked as redundant yet
		RedundantLeave[I] = true;
		cout << " Redundant leaf " << NodeName[I]  << endl; //bebug
	      }
	    }
	  }
	}
      } // end of if I0 is a leave
    }// end of if size=1 SCC
  }// end of all sccs in the first layer

}
//////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////





///////////////////////////////////////////////////////////////////////////////////////
// this modification must be done based on an already built G' of a controller node I
// The new controller (J) and the older one (I) must be in the same SCC
// correspondingly, we should also modify the vector ar[] in the linear programming (LP)
void Network::Modify_Gprime_LP(int I, int J, glp_prob *lp)  
{
  int i = GprimeIndexofOriginalnode[I];
  int j = GprimeIndexofOriginalnode[J];

  // when we change the controller node from I to J in G(A), then in G', only 2 nodes' incoming edgelists are affected
  // so we just update those 2 rows corresponding to those 2 nodes (i and j)' incoming edgelist
  Gprime_Ein[i].remove(Gprime_E);     
  Gprime_Ein[j].push_back(Gprime_E);  
  
  UpdateEin(i, lp); // update rows associated with node-i's incoming edges
  UpdateEin(j, lp); // update rows associated with node-j's incoming edges

  // Note that in G', the last node (Gprime_N-1)'s edgelist is not affected 
  // only one of its outgoing link's head is changed. (But this will not affect the constraint matrix.) 
  Gprime_L[Gprime_E].ChangeHead(j);

}
///////////////////////////////////////////////////////////////////////////////////////




///////////////////////////////////////////////////////////////////////////////////////
// here, we run GLPK for each single node in G(A).
// the structural controllability of each single node will be stored in Cs[i]
void Network::Hosoe_GLPK(char* fname) 
{
  cout << "Control centrality of each node:\n";
 ///////////////////////////////
  RedundantLeave.clear();
  RedundantLeave.resize(N,false);
  MarkRedundantLeaves();
  ////////////////////////////////


  char filename [256];
  sprintf(filename, "%s.ControlCentrality", fname);
  ofstream fout(filename, ios_base::out);
  fout << "#NodeName Cc Cc/N LayerIndex" << endl;

  dc.clear();
  Cc.clear();
  dc.resize(N,0);
  Cc.resize(N,0);

  int count = 1;

  ///////////////////////////////
  CsmaxofLayer.resize(Condensation_Nlayer+1,0); // the maximum Cs of nodes inside each layer of the LCC
  CsminofLayer.resize(Condensation_Nlayer+1,0); // the minimum Cs of nodes inside each layer of the LCC
  CsaveofLayer.resize(Condensation_Nlayer+1,0); // the average Cs of nodes inside each layer of the LCC
  WidthofLayer.resize(Condensation_Nlayer+1,0); // the # of nodes inside each layer of the LCC
  ///////////////////////////////

  for(int layer=1; layer <= Condensation_Nlayer; layer++) {
  //for(int layer=Condensation_Nlayer; layer>=1; layer--) {  // we start the calculation from the top layer to the bottom layer

    int Csmax=0;
    int Csmin=N;
    int Cssum=0;
    int Width=0; // # of nodes in this layer in the LCC

    // consider all the SCCs in this layer
    for(Nbl_itr p = Condensation_Layer_SCClist[layer].begin(); p!= Condensation_Layer_SCClist[layer].end(); p++) {
      int SCC_u = *p;
      int I0 = *AllSCCs[SCC_u].begin();

      //if(SizeofSCC[SCC_u]>1) {
      //cout << "----------------------------------------------------------------------------------------\n";
      //cout << "Consider SCC " << SCC_u << endl; // test
      //cout << "----------------------------------------------------------------------------------------\n";
	  //}

      // this is a leave node (this just happens for those leaves in the lowest layer)
      if(SizeofSCC[SCC_u]==1 && Kout[I0]==0) { 
	dc[I0] = 1;
	Cc[I0] = dc[I0]/(double)N;  
	fout << NodeName[I0] << ' ' << dc[I0] << ' ' << Cc[I0] << ' ' << layer << endl;

	//cout << "Controling node " << I0 <<  " yields controllable subspace with dimension dc = " << dc << endl;
	cout << "dc[" << NodeName[I0] << "]= " << dc[I0] << "    " << count++ << '/' << N << endl;
	//cout << "----------------------------------------------------------------------------------------\n";
	
	if(SCC_ccindex[SCC_u]==lcc_index) {
	  if(dc[I0]>Csmax) Csmax = dc[I0];
	  if(dc[I0]<Csmin) Csmin = dc[I0];
	  Cssum += dc[I0];
	  Width++;

	  //gout << layer << "    " << dc[I0] <<  "  " << NodeName[I0] << endl; 
	}

	continue;
      }
      else {   // for this SCC, construct the new graph G' with controller node = I0

	Gprime_Build(I0);


	////////////////////////////////////////////////////////////////////////////////////////
	// construct the linear program for all the nodes in this SCC
	double z;
	glp_prob *lp = glp_create_prob();
	glp_set_obj_dir(lp, GLP_MAX);
      
	////////////////////////////////////////////////////////////////////////////
	// set the bounds for the auxiliary variable
	int nrows = 2*Gprime_N;     
	//cout << "nrows = " << nrows << endl;
	glp_add_rows(lp, nrows);
	for(int row=1; row<= nrows; row++) {
	  glp_set_row_bnds(lp, row, GLP_FX, 1.0, 1.0);
	}
	////////////////////////////////////////////////////////////////////////////
      
	////////////////////////////////////////////////////////////////////////////
	// set the bounds for the structural variable: x1,x2,.....
	int ncols = Gprime_E; 
	//cout << "ncols = " << ncols << endl;
	glp_add_cols(lp, ncols);
	for(int col=1; col<= ncols; col++) {
	  glp_set_col_bnds(lp, col, GLP_DB, 0.0, 1.0);
	}
	////////////////////////////////////////////////////////////////////////////
	
	////////////////////////////////////////////////////////////////////////////////
	// set the objective coefficient, i.e. the weihts of each structural variable
	// for those edges in G(A,B), assign weight Ce=1
	// for those new edges in G', assign weight Ce=0
	double* Ce = dvector(1, Gprime_E);
	for(int e=1; e<= Gprime_E; e++) {
	  Ce[e] = (BelongtoG[e]) ? 1.0 : 0.0;
	  glp_set_obj_coef(lp, e, Ce[e]);
	}
	////////////////////////////////////////////////////////////////////////////////


	////////////////////////////////////////////////////////////////////////////////
	//cout << "\nGLP set rows ...";
	int k;
	for(int i=0; i< Gprime_N; i++) {
	  UpdateEin(i, lp); // set rows associated with node-i's incoming edges
	  UpdateEout(i, lp); // set rows associated with node-i's outgoing edges
	}
	////////////////////////////////////////////////////////////////////////////////


	glp_smcp parm;
	glp_init_smcp(&parm);
	//parm.meth = GLP_DUAL;
	parm.msg_lev = GLP_MSG_ERR;

	// now perform the SIMPLEX algorithm for each node
      	for (Nbl_itr q = AllSCCs[SCC_u].begin(); q!=AllSCCs[SCC_u].end(); q++) {
	  int I = *q;

	  if(I!=I0) { 
	    //cout << I0 << ' ' << I << endl; //debug
	    // if G' has been built for this SCC, then we just need to modify it for different controller node 
	    Modify_Gprime_LP(I0, I, lp); 

	    // Note that the following construction is crucial to avoid the error: glp_simplex: initial basis is invalid
	    glp_std_basis(lp);
	    // update I0 for next node
	    I0 = I;               
 	  }

	  
	  //cout << " GLP SIMPLEX running ...\n";
	  //glp_simplex(lp, NULL);
	  glp_simplex(lp, &parm);
	  z = glp_get_obj_val(lp);

	  //cout << "Controling node " << I << " yields controllable subspace with dimension dc = " << z << endl;
	  //cout << "dc[" << I << "]= " << z << endl;
	  cout << "dc[" << NodeName[I] << "]= " << z << "    " << count++ << '/' << N << endl;

	  //cout << "\nThe cactus configuration contains :\n";
	  vector<bool> BelongtoCyclePartition(Gprime_E+1, false); // index starts from 1

	  set<int> ControllableSubsystem;
	  for(int e=1; e<=Gprime_E; e++) {
	    int xe = glp_get_col_prim(lp, e);
	    BelongtoCyclePartition[e] = xe;

	    if(xe==1) {
	      //cout << "x" << e << " = " << xe;
		
	      if(BelongtoG[e] && BelongtoCyclePartition[e]) {
		//cout << "  edge " << e << " : " 
		//   << OriginalIndexofGprimenode[Gprime_L[e].GetHead()] 
		//   << "-->" << OriginalIndexofGprimenode[Gprime_L[e].GetTail()];
		int h = OriginalIndexofGprimenode[Gprime_L[e].GetHead()];
		int t = OriginalIndexofGprimenode[Gprime_L[e].GetTail()];
		//cout << "  edge " << e << " : " << h << "-->" << t;
		if(h<N) ControllableSubsystem.insert(h);
		if(t<N) ControllableSubsystem.insert(t);
	      }
	      //cout << endl;
	    }
	  }
	  //cout << "\nNode " << I << "'s controllable subsystem contains : ";
	  //for(set<int>::iterator p=ControllableSubsystem.begin(); p!=ControllableSubsystem.end(); p++) {
	  //cout << (*p) << ',';
	  //}
	  //cout << "\n----------------------------------------------------------------------------------------\n";
	  

	  
	  dc[I] = z;
	  Cc[I] = z/(double)N;  


	  fout << NodeName[I] << ' ' << dc[I] << ' ' << Cc[I] << ' ' << layer << endl;

	  if(SCC_ccindex[SCC_u]==lcc_index) {
	    if(dc[I]>Csmax) Csmax = dc[I];
	    if(dc[I]<Csmin) Csmin = dc[I];
	    Cssum += dc[I];
	    Width++;

	    //gout << layer << "    " << dc[I] <<  "  " << NodeName[I]  << endl; 
	  }
	}
	
	free_dvector(Ce, 1, Gprime_E);
	glp_delete_prob(lp);
	Gprime_Clear(); // clear the G' for next call

      } // end of loop for the current SCC
  
    }// end of loop for the current layer

    CsmaxofLayer[layer] = Csmax;
    CsminofLayer[layer] = Csmin;
    CsaveofLayer[layer] = Cssum/(double)Width;
    WidthofLayer[layer] = Width;
  
  } // end of all layers



  fout.close();

  
  Cc_avg = 0;
  for(int i=0; i<N; i++) {
    Cc_avg  += Cc[i];
  }  

  Cc_avg /= (double)N;

}
///////////////////////////////////////////////////////////////////////////////////////




